import React , { useState }  from 'react';
import { Text, StyleSheet, View, Button, Image} from "react-native";

const counterScreen = () => {
const [counter, SetCounter] = useState(0);

  return (<View>
  			<Button title="Increase" onPress={() => {
  				SetCounter( counter + 1 );
  			}} />
    		<Button style={{width:100}} title="Decrease" onPress={() => {
  				SetCounter( counter -	 1 );
  			}} />
  			<Text> Current Count: {counter}</Text>
  		  </View>);
};

const styles = StyleSheet.create({});


export default counterScreen;