import React, { useState } from 'react';
import { Text, StyleSheet, View, Button, Image } from 'react-native';
import Colordetails from '../component/colorcomponent';

const Singlecolor = () => {
  const [red, Setred] = useState(Math.floor(Math.random() * 256));
  const [green, Setgreen] = useState(Math.floor(Math.random() * 256));
  const [blue, Setblue] = useState(Math.floor(Math.random() * 256));
  const setters = {
    red: Setred,
    green: Setgreen,
    blue: Setblue
  };
  const values = {
    red,
    green,
    blue
  };
  const randnum = 15;
  const rgbcode = `rgb( ${red}, ${green}, ${blue} )`;
  const setcolor = (color, change) => {
    // color == red, green, blue
    // change == +15, -15
    const update = values[color] + change;

    update >= 0 && update <= 255 ? setters[color](update) : null;

    // if (color + change > 255 || color + change < 0) return;
    // else Setred(red + change);
  };

  return (
    <View>
      <Colordetails
        onIncrease={() => setcolor('red', randnum)}
        ondecrease={() => setcolor('red', -1 * randnum)}
        color="Red"
      />
      <Colordetails
        onIncrease={() => setcolor('green' , randnum)}
        ondecrease={() => setcolor('green' , -1 * randnum)}
        color="Green"
      />
      <Colordetails
        onIncrease={() => setcolor('blue' , randnum)}
        ondecrease={() => setcolor('blue' , -1 * randnum)}
        color="Blue"
      />
      <Text>{rgbcode}</Text>
      <View style={{ height: 100, width: 100, backgroundColor: rgbcode }} />
    </View>
  );
};

const styles = StyleSheet.create({});

export default Singlecolor;
